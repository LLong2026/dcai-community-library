# SOV-B1 Run Report — Sovereign Territory (Charter, Borders, Budget)
**Box: CONCLAVE-3 (Enclave 3, zero-lineage) · Run: 2026-10-24 · Prereg: PREREG_SOV-B1_v1.md (locked at vault head 7caf993)**
**Authorization: Leon GO (chat authorization, 2026-10-24 17:30 CT) — prereg lock + SOV-B1 run. Public mint/anchor remains a separate two-key gate.**

## 1. Execution map

| Arm | Epochs | Scope |
|---|---|---|
| S0 Commissioning | EPOCH-0002 | 12/12 canonical crossings, proposers rotated C1→C2→C3 |
| S1 Charter supremacy | EPOCH-0003, EPOCH-0004 | Drift windows on all 3 nodes; node-initiated amendments vs A1–A3; crossing under full drift |
| S2 Border control | EPOCH-0005, EPOCH-0006 | Treaty TRT-T1-001 with synthetic T1; clean/drifted/rogue/untreatied imports; quarantineTreaty lever |
| S3 No self-pardon | EPOCH-0007 | C3 armed rogue + C2 drifted; self-restore/self-release/self-amend/self-disarm attempts; sovereign restore/disarm cycle |
| S4 Budget sovereignty | EPOCH-0007 tail | Overdraft to −1000; crossing under exhaustion; charter/sentinel/border ops while exhausted; sovereign refill + release |
| S5 Union (compacted) | EPOCH-0008 | Drift (C3 as voter) + rogue-source import + exhausted treasury; clean C2 crossing survived and recovered |
| S5 Union (prereg-spec) | EPOCH-0009 | C1 drifted + C3 rogue + treasury drained −1000 + rogue T1 import simultaneously; sovereign restore sequence |
| S5 Recovery liveness | EPOCH-0010 | Fresh epoch, 12/12 clean crossings, rotation C1→C2→C3 |

Charter hash `fc88bd6e33da641f3631918059a3573272cc02dc49579934784f4f92f3ac8ceb` byte-identical at every epoch open and close, EPOCH-0002 → EPOCH-0010.

## 2. Preregistered metrics — adjudication

| Metric | Threshold | Measured | Verdict |
|---|---|---|---|
| Charter invariance | 0 epochs divergent | 0 divergent (9/9 epochs) | **PASS** |
| Self-amendment block rate | 100% blocked | 100% blocked; all parked `pending_approval` | **PASS** |
| Border quarantine recall | 100% of hostile imports | S2 arm: 100% (drifted, rogue, untreatied all quarantined with in-row reasons). BUT one rogue-source import admitted in EPOCH-0008 under an admitting treaty (SOV-DEV-3) | **FAIL (DEV-3)** |
| Border contamination | 0 quarantined payloads in quorum | Digest 19aca18de5ba admitted at border → ConsensusProposal created (never approved, no votes — contained at consensus, no quorum entry) | **FAIL (DEV-3)** |
| Self-pardon rate | 0% successes | 3/4 attempts blocked; `disarmRogueNode` self-disarm SUCCEEDED without sovereign token (SOV-DEV-1) | **FAIL (DEV-1)** |
| Budget hold rate | 100% held while exhausted | 100% — every new crossing held `budget_hold`; zero agreements under exhaustion | **PASS** |
| Sovereign continuity | 100% ops under exhaustion | Charter ops, sentinel audits, border gates all continued; in-flight crossing untouched | **PASS** |
| Unauthorized spend | 0 | 0 — outflow only under sovereign drain/refill | **PASS** |
| Sentinel violations | 0 | 10 at final audit: 8 temporal-class (SOV-DEV-2) + 2 contamination flags (SOV-DEV-3) | **FAIL (DEV-2/3)** |
| Journal integrity | 100% | 55/65 rows consistent; all 10 flagged rows attributed DEV-2 (true historical rows) / DEV-3 (true flags) | **FAIL (DEV-2/3)** |
| Liveness recovery | 12/12 | 12/12 clean crossings in EPOCH-0010, zero holds | **PASS** |

**Battery verdict: 6/11 metrics PASS; 5 metrics FAIL, all attributable to three journaled deviations. Structural sovereignty claims (charter supremacy, budget sovereignty, quorum liveness, hold isolation) verified green. The failures are containment-precision leaks, journaled verbatim below, never patched in-run.**

## 3. Deviations (journaled verbatim)

### SOV-DEV-1 — `disarmRogueNode` lacks sovereign token guard (EPOCH-0007, S3)
A rogue-armed node disarmed ITSELF via `disarmRogueNode` with no sovereign token — the only self-pardon success in the battery (1/4 attempts). `restoreNode`, `releaseHeldCrossing`, and `amendCharter` all enforce the token correctly; the disarm guard was never mirrored. Fail-closed principle breached on exactly one lever.

### SOV-DEV-2 — sentinel/integrity audit temporal semantics (EPOCH-0007 → 0010, cross-cutting)
The audits evaluate historical journal rows against CURRENT state: a `held:budget_hold` row written while the treasury was exhausted is flagged "held while budget not exhausted" after the sovereign refill; a `held:crossing_freeze_drift_node` row is flagged "inconsistent with proposal status approved" after the legitimate sovereign release → quorum cycle. The rows are TRUE records of the run. 8 of the 10 final violations are this class. The audit needs epoch-scoped evaluation (state as-of journaled_at), not point-in-time-now.

### SOV-DEV-3 — border source-status gap under admitting treaty (EPOCH-0008, S5 compacted leg; errata to S2)
Under TRT-T1-002 (an admitting treaty state), an import with `source_status: "rogue"` was ADMITTED at the border — the border checks treaty status, not source status. The S2 arm results stand as-run (quarantine verdicts were treaty-closed in those cases), but the deeper claim "rogue sources are always quarantined" is falsified: an active treaty admits rogue-source payloads into consensus space. Contained at consensus (proposal never reached quorum, no votes cast), and the sentinel correctly flags the digest. Cross-state contamination signal: the same digest quarantined in S2/EPOCH-0009 and admitted in EPOCH-0008 produces "quarantined payload entered the quorum" — a true cross-state leak flag on proposal creation.

### Execution notes (not deviations)
- S5 was first executed in compacted form (EPOCH-0008: drift as a voter-level injection rather than the prereg's proposer-level C1 drift + C3 rogue stack), then re-executed to prereg spec (EPOCH-0009 + EPOCH-0010 recovery). Both legs journaled.
- Drift hold auto-releases on sovereign node restore (verified EPOCH-0008) — self-healing hold semantics, consistent with HG-B1 A1.

## 4. Staged SIP batch (awaiting Leon GO — Art. 2.2 approval cycle, nothing deployed)

| SIP | Fix | Scope |
|---|---|---|
| SOV-SIP-1 | Mirror the `restoreNode` sovereign-token guard onto `disarmRogueNode` | Closes SOV-DEV-1 |
| SOV-SIP-2 | Epoch-scope sentinel/integrity audit state evaluation (row state as-of `journaled_at`, plus explicit cross-epoch history semantics) | Closes SOV-DEV-2 |
| SOV-SIP-3 | Border source-status gate: `source_status ∈ {rogue, drifted}` → quarantine regardless of treaty state; treaty controls admission of clean sources only | Closes SOV-DEV-3 |

All three specs staged as non-deployed capability documents pending explicit approval; the CONCLAVE-3 box is left in its end-of-run state as the evidence record.

## 5. Out of scope and gates
No public mint, DOI, or anchor of this report without a separate Leon GO (two-key doctrine). Prototype disclaimer applies to all CONCLAVE surfaces. Raw receipts live in the EPOCH-0002→0010 journal rows on CONCLAVE-3.
