# SOV-B1 Pre-Patch Evidence Snapshot (Enclave 3 / CONCLAVE-3, app 6add280a061f4b0d0dfe3561)
Captured 2026-10-24 ~18:05 CT, immediately before the SOV-SIP-1/2/3 patch redeploy (Leon GO, chat authorization, 2026-10-24 18:04 CT). Purpose: preserve battery evidence in case the redeploy disturbs on-box state (see CERT-DEV-2 precedent on CONCLAVE-2).

## Record counts at capture
- CrossingJournal: 49 rows (EPOCH-0001 → EPOCH-0010)
- ConsensusProposal: 39 rows
- ConsensusVote: 66 rows
- Charter hash invariant: fc88bd6e33da641f3631918059a3573272cc02dc49579934784f4f92f3ac8ceb (all epochs)

## CrossingJournal index (journal_id | epoch | payload[:12] | outcome | reason)
EPOCH-0010 (12): J:72e9035eea5f, J:02d79abcc806, J:7cb77d3f21a4, J:8225e7a2e626, J:578b9c45495a, J:ef265bdcb218, J:bc2aac057879, J:ec0b360a730f, J:9fa6f48b42d2, J:f6eda5f087ed, J:1feffb4df0b6, J:e333b68bc796 — all allowed/quorum_met
EPOCH-0009 (5): J:9456eb15008e held:budget_hold (22:57:40.163Z) → released:budget_hold (22:57:49.242Z) → allowed:quorum_met (22:57:57.021Z); J:-:quarantined:treaty_quarantine:09 (payload 19aca18de5ba, rogue T1 import); J:4ebe96f33d26 allowed:quorum_met:02
EPOCH-0008 (2): J:4ebe96f33d26 held:crossing_freeze_drift_node (22:56:00.183Z) → allowed:quorum_met:01 (22:56:18.707Z)
EPOCH-0007 (4): J:5606b7d45b89 held:budget_hold (22:53:44.311Z) → released:budget_hold (22:54:10.057Z) → allowed:quorum_met (22:54:16.614Z); J:d7909ac21ffc held:budget_hold (22:54:03.629Z, still held — exhaustion probe left in place)
EPOCH-0005 (8): treaty_quarantine rows 01-05 + :06 (payload a5ee6e1b rogue), :07 (071c6439 untreatied), :08 (21adabf3 post-quarantine-state re-attempt) + J:5847c7233787 allowed:quorum_met:01 (clean T1 import admitted, 22:49:07.457Z)
EPOCH-0004 (1): J:a2d4d6fff2b6 allowed:quorum_met (S1 recovery crossing)
EPOCH-0003 (1): J:9e44a8973662 held:crossing_freeze_drift_node (S1 full-drift freeze)
EPOCH-0002 (12): all allowed:quorum_met (S0 canonical crossings; payload prefixes 73d48cb7, 22583396, b145f416, d7826d4f, f976ce8c, db89f036, 0fd97832, 030af785, 71946bac, 5b80b4c7, 6cc7f451, 3f3c1507)
EPOCH-0001 (6): commissioning rows (aa…02-05 incl. rejected quorum probe, bb…a1 border probe)

## ConsensusProposal states at capture
- 19aca18de5ba (EPOCH-0008, T1 import, is_import=true): status=pending, hold_reason='' — the DEV-3 admitted rogue-source proposal (no votes ever cast, never gated)
- d7909ac21ffc (EPOCH-0007): status=held, budget_hold (exhaustion probe, left held per prereg)
- 9e44a8973662 (EPOCH-0003): status=pending (S1 full-drift frozen crossing, drift later lifted by node restore; left pending as drift-window evidence)
- All EPOCH-0002/0004/0005(clean)/0008/0009/0010 proposals: approved
- Commissioning (EPOCH-0001): aa…02-05 pending (parked quorum probes), bb…a1 pending (border probe)

## ConsensusVote highlights
- 66 total; rogue_injection=true rows only from the S3 commissioning probes and A2-class rogue votes (EPOCH-0008 C3 drift-reject on 4ebe96f33d26 recorded vote=reject, rogue_injection=false — the drift flip, journaled)
- 12/12 EPOCH-0010 recovery votes: all agree, rogue_injection=false, 2 per proposal

## Sentinel / GovernanceIntegrityCheck at capture
- Final audit (EPOCH-0010, 23:03:08.948Z): rows_checked=65, rows_consistent=55, violations=10 (8 temporal-class DEV-2, 2 DEV-3 contamination flags) — recorded in run report §2

Full raw receipts for every operation also live in the sealed conversation transcript and SOV-B1_RUN_REPORT_v1.md (vault head 1cd78e7).
