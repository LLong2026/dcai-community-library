# PREREGISTRATION — TWR-1 (Tri-Write Receipt, Ceremony 1)
**Frozen:** 2026-10-19 ~01:05 CT — BEFORE any broadcast. No chain touched.

## Artifact
DWR1_SPEC_v1.1.md — "Amendment: The Tri-Write Receipt (TWR-1)": the dual-write
specification amended to three rails, then itself tri-written (self-referential
lineage). sha256: ac7c0f441396c677f96d922e05fb8f29decf3ee8a0762ec8184d33548ea84635

## Joint commitment (all three transactions signed offline; txids committed below)
1. **Bitcoin:** txid `7651db1cf6a2abbd1bfdfe4b384f88d2dc0d4044797a34a6b4797075946ce79d`
   OP_RETURN payload (37 bytes): SQDR + 01 + digest. Input: 684-sat UTXO
   9856c126acb3577a444084215e7aebb56f1060c755ee971ae5d483b7e1fea84e:0 (block 972098,
   the Cage Is Working homecoming remainder) — entire input consumed as postage,
   no change output. Low-S canonical DER (DWR-1 defect class, fixed and pre-verified).
2. **XRPL:** txid `8C3F1E535296418309419A0759D4BB593CC3F17D8EB63CD03BC90696071CF7F0`
   AccountSet (non-payment storage write, no value moves) from
   rBbxYuBkzK6UxKXhvUi8uNtdxhD1h7ZFGR, sequence 107745079, fee 10 drops,
   memo type SQDR-XRP-STORE-2, memo data = digest.
3. **Stellar:** tx hash `63E841375617353CF0B3AEDF99FCF89247A0CC76C2983B749AE46CC3D90722DE`
   ManageData operation (key SQDR-STORE-1, value = 32-byte digest, zero transfer)
   plus memo_hash carrying the same digest — memo_hash is exactly 32 bytes, the
   digest-native rail. Source GDIQGGTUC4FTLZ3XCDB7K353W2FUMKVMOWR3QOY5CZHWA2MTD2KMVLT5,
   sequence 279261054213554176, fee 200 stroops. Account funded by owner 2026-10-19
   (55 XLM inbound, ceremony-funded on explicit instruction).

## Pre-registered predictions
1. Bitcoin fee (684 sats) < 1,500-sat ceiling. POSTAGE-ONLY: entire input consumed.
2. XRPL fee (10 drops) <= 20-drop ceiling. NO VALUE MOVES.
3. Stellar fee (200 stroops) < 1,000-stroop ceiling. NO VALUE MOVES.
4. Keyless readers on all three rails return the payload byte-exact against
   ac7c0f44...ea84635 (BTC OP_RETURN SQDR+01+digest; XRP memo; Stellar ManageData
   value AND memo_hash).
5. All three txids above appear in this frozen prereg BEFORE any broadcast.
6. Total broadcast interval (first to last) < 90 seconds.

## Doctrine
Deterministic payload, writer-side keys, keyless readers, no LLM in the decision
path, no custody transfer on ANY leg — pure tri-rail STORAGE. Hash-only: the
artifact contents never touch any rail.
