#!/usr/bin/env python3
"""TWR-1 execution: broadcast ALL THREE legs back-to-back, record intervals, verify."""
import json, time, urllib.request

btc = json.load(open("btc_twr.json"))
xrp = json.load(open("xrp_twr.json"))
st  = json.load(open("stellar_twr.json"))
DIGEST = "ac7c0f441396c677f96d922e05fb8f29decf3ee8a0762ec8184d33548ea84635"
t_start = time.time()

# LEG 1: Bitcoin
req = urllib.request.Request("https://blockstream.info/api/tx", data=btc["raw"].encode(),
    headers={"Content-Type":"text/plain"})
try:
    r1 = urllib.request.urlopen(req, timeout=60).read().decode()
    ok1 = (r1 == btc["txid"] or len(r1) == 64)
    print(f"LEG 1 BTC broadcast OK ({time.time()-t_start:.1f}s):", r1)
except Exception as e:
    print("LEG 1 BTC FAIL:", e); ok1 = False; r1 = None
t1 = time.time()

# LEG 2: XRPL
req = urllib.request.Request("https://xrplcluster.com",
    data=json.dumps({"method":"submit","params":[{"tx_blob": xrp["signed_blob"]}]}).encode(),
    headers={"Content-Type":"application/json"})
r = json.loads(urllib.request.urlopen(req).read())["result"]
eng = r.get("engine_result"); th = r.get("tx_json",{}).get("hash","")
ok2 = (eng == "tesSUCCESS" and th.upper() == xrp["txid"])
print(f"LEG 2 XRP submit {eng} ({time.time()-t1:.1f}s): hash match {'PASS' if th.upper()==xrp['txid'] else 'FAIL'}")
t2 = time.time()

# LEG 3: Stellar
req = urllib.request.Request("https://horizon.stellar.org/transactions",
    data=json.dumps({"tx": st["xdr"]}).encode(),
    headers={"Content-Type":"application/json"})
try:
    resp = json.loads(urllib.request.urlopen(req, timeout=60).read())
    ok3 = resp.get("successful") is True and resp.get("hash","").upper() == st["hash"]
    print(f"LEG 3 Stellar submit ({time.time()-t2:.1f}s): success={resp.get('successful')} hash match {'PASS' if resp.get('hash','').upper()==st['hash'] else 'FAIL'}")
except Exception as e:
    body = getattr(e, "read", lambda: b"")()
    print("LEG 3 Stellar FAIL:", str(e)[:80], body.decode()[:300] if body else ""); ok3 = False; resp = {}

total = time.time() - t_start
print(f"TOTAL BROADCAST INTERVAL: {total:.1f}s (ceiling 90s)")
json.dump({"btc_broadcast": ok1, "btc_wtxid_returned": r1,
           "xrp_result": eng, "xrp_hash_match": ok2,
           "stellar_result": resp.get("hash"), "stellar_success": ok3,
           "total_interval_seconds": round(total,1), "t_start": t_start},
          open("EXEC_LOG.json","w"), indent=1)
print("G1:", "PASS" if ok1 else "FAIL", "| G2:", "PASS" if ok2 else "FAIL", "| G2S:", "PASS" if ok3 else "FAIL")
