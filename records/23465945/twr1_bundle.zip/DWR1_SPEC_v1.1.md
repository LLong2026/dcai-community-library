# DWR1 SPEC v1.1 — Amendment: The Tri-Write Receipt (TWR-1)

**Supersedes:** DWR1_SPEC_v1.0 (The Dual-Write Receipt), which remains in force as the
dual-rail doctrine. This amendment adds a third rail and generalizes the ceremony.
**Status:** Frozen 2026-10-19, 00:55 CT. This document is the TWR-1 artifact: the
dual-write specification, amended to three rails, then itself tri-written.

## Amendment: Third Rail (Stellar)

The Dual-Write Receipt is generalized to the **Tri-Write Receipt**: the same 32-byte
SHA-256 digest stored simultaneously on three mainnets under one joint prior commitment.

1. **Bitcoin leg** (unchanged from v1.0): OP_RETURN storage write, postage-only,
   no custody transfer, deterministic signer, low-S canonical DER signatures.

2. **XRPL leg** (unchanged from v1.0): non-payment storage write. AccountSet with
   memo carrying the digest. The ledger as a data store, not a payment rail.

3. **Stellar leg** (NEW): ManageData operation — account state key-value write,
   zero value transfer, the direct analog of the XRPL AccountSet storage pattern.
   Key: SQDR-STORE-1. Value: the 32-byte digest (fits ManageData's 64-byte ceiling).
   The same transaction carries a memo_hash — Stellar's memo_hash field is exactly
   32 bytes, so the digest fits with zero padding and zero marker bytes. Where the
   Bitcoin leg needs an OP_RETURN marker prefix and the XRPL leg wraps in a memo
   envelope, the Stellar memo_hash is native-sized to SHA-256: the cleanest
   digest-native rail of the three.

## Joint Commitment (generalized)

No protocol provides cross-chain atomicity across two rails, let alone three. The
deterministic substitute is unchanged: ALL transaction IDs are computed offline,
frozen in a hashed pre-registration BEFORE any broadcast, then fired back-to-back.
Commitment order in the prereg: Bitcoin, XRPL, Stellar. Broadcast interval ceiling
is raised to 90 seconds (three rails).

## Gates (unchanged unless noted)

- G1 Bitcoin broadcast: fee ceiling 1,500 sats (unchanged)
- G2 XRPL: fee ceiling 20 drops (unchanged)
- G2S Stellar: fee ceiling 1,000 stroops (new; expected 200: base 100 + 100 for the ManageData op)
- G3 keyless byte-exact read-backs on all three rails
- G4 all txids in frozen prereg before any broadcast
- G5 total broadcast interval < 90 seconds

## Doctrine (unchanged)

Deterministic payload, writer-side keys, keyless readers, no LLM in the decision
path, no custody transfer on any leg, disclosed failures, append-only receipts.
Hash-only: the artifact contents never touch any rail; only the 32-byte digest rides.
