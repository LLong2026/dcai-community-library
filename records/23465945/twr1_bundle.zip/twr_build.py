#!/usr/bin/env python3
"""TWR-1 offline builder: construct+sign ALL THREE rails, precompute txids. NO BROADCAST."""
import hashlib, json
import bitcoin
from bitcoin.core import CMutableTransaction, CMutableTxIn, CMutableTxOut, COutPoint, lx, CScript
from bitcoin.core.script import OP_RETURN, OP_0, SIGHASH_ALL, CScriptWitness
from bitcoin.core import CTxWitness, CTxInWitness
from bitcoin.wallet import CBitcoinSecret, P2WPKHBitcoinAddress

DIGEST = bytes.fromhex("ac7c0f441396c677f96d922e05fb8f29decf3ee8a0762ec8184d33548ea84635")
UTXO = {"txid": "9856c126acb3577a444084215e7aebb56f1060c755ee971ae5d483b7e1fea84e", "vout": 0, "value": 684}
KA = "/app/tmp_push/fh_push/tokenization-adoption/seed-mode/dropbox/dropbox_writer_key_mainnet.json"
MARKER, VERSION = b"SQDR", 0x01

def sha(b): return hashlib.sha256(b).digest()
def dsha(b): return hashlib.sha256(sha(b)).digest()
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
def der_parse(sig):
    assert sig[0] == 0x30; i = 2
    assert sig[i] == 0x02; l = sig[i+1]; r = int.from_bytes(sig[i+2:i+2+l], "big"); i += 2 + l
    assert sig[i] == 0x02; l = sig[i+1]; s = int.from_bytes(sig[i+2:i+2+l], "big")
    return r, s
def der_encode(r, s):
    def enc(i):
        b = i.to_bytes((i.bit_length() + 7) // 8 or 1, "big")
        if b[0] & 0x80: b = b"\x00" + b
        return bytes([0x02, len(b)]) + b
    body = enc(r) + enc(s)
    return bytes([0x30, len(body)]) + body
def low_s(sig):
    r, s = der_parse(sig)
    if s > N // 2: s = N - s
    return der_encode(r, s)
def wpkh_addr(secret):
    h160 = hashlib.new("ripemd160", sha(bytes(secret.pub))).digest()
    return P2WPKHBitcoinAddress.from_scriptPubKey(CScript([OP_0, h160]))
def bip143(tx, idx, amount, h160):
    script_code = b"\x19\x76\xa9\x14" + h160 + b"\x88\xac"
    prevouts = b"".join(ti.prevout.serialize() for ti in tx.vin)
    seqs = b"".join(ti.nSequence.to_bytes(4, "little") for ti in tx.vin)
    outs = b"".join(to.serialize() for to in tx.vout)
    preimage = (tx.nVersion.to_bytes(4,"little") + dsha(prevouts) + dsha(seqs) +
                tx.vin[idx].prevout.serialize() + script_code + amount.to_bytes(8,"little") +
                tx.vin[idx].nSequence.to_bytes(4,"little") + dsha(outs) +
                tx.nLockTime.to_bytes(4,"little") + (1).to_bytes(4,"little"))
    return dsha(preimage)

# --- LEG 1: Bitcoin OP_RETURN postage-only (cage homecoming remainder as postage) ---
wif = json.load(open(KA))["wif"]
secret = CBitcoinSecret(wif); addr = wpkh_addr(secret)
h160 = hashlib.new("ripemd160", sha(bytes(secret.pub))).digest()
payload = MARKER + bytes([VERSION]) + DIGEST
txin = CMutableTxIn(COutPoint(lx(UTXO["txid"]), UTXO["vout"])); txin.scriptSig = CScript()
tx = CMutableTransaction([txin], [CMutableTxOut(0, CScript([OP_RETURN, payload]))])
tx.vin[0].nSequence = 0xFFFFFFFF
sighash = bip143(tx, 0, UTXO["value"], h160)
sig = low_s(secret.sign(sighash)) + b"\x01"
tx.wit = CTxWitness([CTxInWitness(CScriptWitness([sig, bytes(secret.pub)]))])
raw = tx.serialize().hex()
txid = bitcoin.core.b2lx(dsha(tx.serialize()))
print("LEG 1 BTC txid:", txid)
json.dump({"txid": txid, "raw": raw, "payload_hex": payload.hex(),
           "input": f"{UTXO['txid']}:{UTXO['vout']}", "fee_sats": 684},
          open("btc_twr.json","w"), indent=1)

# --- LEG 2: XRPL AccountSet storage write (no payment) ---
from xrpl.wallet import Wallet
from xrpl.models.transactions import AccountSet, Memo
from xrpl.transaction import sign as xrpl_sign
import xrpl.core.binarycodec as bc
wA = Wallet.from_seed(json.load(open("/app/tmp_push/fh_push/tokenization-adoption/xrp-rail/xrp_writer_key_mainnet_a.json"))["seed"])
tx_xrp = AccountSet(account=wA.classic_address, fee="10", sequence=107745079,
                 last_ledger_sequence=107755710,
                 memos=[Memo(memo_type="SQDR-XRP-STORE-2".encode().hex(),
                              memo_format="hex".encode().hex(),
                              memo_data=DIGEST.hex())])
signed = xrpl_sign(tx_xrp, wA)
blob = bc.encode(signed.to_xrpl())
h = hashlib.sha512(bytes.fromhex("54584E00" + blob)).digest()[:32].hex().upper()
print("LEG 2 XRP txid:", h)
json.dump({"txid": h, "account": wA.classic_address, "fee_drops": 10,
           "sequence": 107745078 + 1, "memo_type": "SQDR-XRP-STORE-2",
           "memo_data": DIGEST.hex(), "signed_blob": blob},
          open("xrp_twr.json","w"), indent=1)

# --- LEG 3: Stellar ManageData + memo_hash (digest-native rail) ---
from stellar_sdk import Keypair, TransactionBuilder, Network
from stellar_sdk.memo import HashMemo
kA = Keypair.from_secret(json.load(open("/app/tmp_push/fh_push/tokenization-adoption/stellar-rail/stellar_writer_key_mainnet_a.json"))["secret"])
source = kA.public_key
from stellar_sdk import Account
tb = TransactionBuilder(
    Account(source, 279261054213554176),
    Network.PUBLIC_NETWORK_PASSPHRASE, base_fee=100)
tb.set_timeout(300)
tb.append_manage_data_op(data_name="SQDR-STORE-1", data_value=DIGEST)
tb.add_memo(HashMemo(DIGEST))
tx_s = tb.build()
tx_s.sign(kA)
env = tx_s.to_xdr()
th = hashlib.sha256(bytes.fromhex(env).decode("hex").hex() if False else base64_to_hex(env)).hexdigest().upper() if False else None
import base64
th = hashlib.sha256(base64.b64decode(env)).hexdigest().upper()
print("LEG 3 Stellar tx hash:", th)
print("LEG 3 XDR len:", len(env))
json.dump({"hash": th, "xdr": env, "account": source,
           "fee_stroops": 200, "op": "ManageData SQDR-STORE-1 + memo_hash",
           "memo_hash": DIGEST.hex()},
          open("stellar_twr.json","w"), indent=1)
print("ALL THREE LEGS SIGNED OFFLINE — NOTHING BROADCAST")
