# TWR-1 RUNLOG — Tri-Write Receipt Ceremony 1
**Date:** 2026-10-19 (00:52–01:20 CT) | **Operator:** Leon Calvin Long II | **Verdict: PASS — with one disclosed identifier-form defect (G4 partial, Stellar leg).**

## Timeline
1. Owner GO (00:52 CT). Spec v1.1 written and frozen: DWR1_SPEC_v1.1.md — the dual-write
   spec amended to three rails, then itself tri-written (self-referential lineage).
   sha256 ac7c0f441396c677f96d922e05fb8f29decf3ee8a0762ec8184d33548ea84635.
2. All three legs constructed and signed OFFLINE. Bitcoin: OP_RETURN postage-only write
   spending the 684-sat Cage Is Working homecoming UTXO (9856c126...:0, block 972098) —
   the cage remainder became the tri-write postage, in full. XRPL: AccountSet (no payment,
   no value moves) with memo SQDR-XRP-STORE-2, 10 drops, sequence 107745079. Stellar:
   ManageData (key SQDR-STORE-1, value = digest, zero transfer) + memo_hash carrying the
   same digest — memo_hash is exactly 32 bytes, the digest-native rail. Funded by owner's
   55 XLM inbound (2026-10-19, explicit ceremony instruction).
3. Prereg frozen (sha 0d10a0449b628d11628bdfbfb747e73dde4d7c5941b74ea1173dc21ffad65beb)
   with all three pre-computed transaction identifiers BEFORE broadcast.
4. Broadcast: BTC tx 7651db1c... at T+0.3s; XRP tx 8C3F1E53... at T+0.5s; Stellar submit
   retried once (Horizon required form-encoded POST) and landed T+9s (ledger 65020686).
5. Keyless read-backs: BTC OP_RETURN byte-exact (SQDR+01+digest); XRP memo byte-exact
   (validated ledger 107755630); Stellar ManageData value byte-exact AND memo_hash
   byte-exact (Horizon reports memo base64; decoded = digest exactly).

## Predictions vs outcome
| # | Prediction | Outcome |
|---|------------|---------|
| 1 | BTC fee < 1,500 sats | PASS — 684 sats postage-only |
| 2 | XRP fee <= 20 drops | PASS — 10 drops, no value moved |
| 3 | Stellar fee < 1,000 stroops | PASS — 100 stroops charged (predicted 200; favorable deviation disclosed) |
| 4 | Byte-exact read-backs all three rails | PASS — 4/4 (ManageData value, memo_hash, OP_RETURN, XRP memo) |
| 5 | All txids in frozen prereg before broadcast | PARTIAL — see defect disclosure |
| 6 | Broadcast interval < 90s | PASS — 9s (first broadcast to Stellar ledger close) |

## DEFECT DISCLOSURE (post-broadcast, per append-only doctrine)
**G4 identifier-form defect, Stellar leg.** The prereg committed the Stellar leg's
identifier as sha256 of the FULL SIGNED ENVELOPE (63E84137...C90722DE), not Stellar's
network transaction hash format. The broadcast transaction's network hash is
019bdac55e97b04201df89e8c3de409ef743605a75f0e090498415b3a0a2dd68. The committed
envelope hash IS a deterministic, binding, pre-broadcast commitment to the exact signed
bytes (verified: sha256 of the submitted XDR envelope reproduces 63E84137... byte-exact),
so the integrity intent of G4 holds — but the identifier FORM was wrong for the rail and
is scored as PARTIAL, not PASS. Both identifiers are published here. Bitcoin and XRPL
committed identifiers were exact (BTC broadcast returned wtxid 8996bd89..., consistent
with segwit indexing; committed txid 7651db1c... is the canonical txid).

## Significance
First tri-rail storage ceremony in the corpus: the same 32-byte digest on Bitcoin,
XRPL, and Stellar mainnets under one joint prior commitment, with NO custody transfer
on ANY leg. The artifact is the dual-write spec amended to three rails — the paper that
defined dual-write is the first thing tri-written. Total storage cost: 684 sats +
10 drops + 100 stroops.
