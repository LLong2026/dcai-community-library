#!/usr/bin/env python3
"""DWR-1 offline builder: construct+sign BOTH rail writes, precompute txids.
NO BROADCAST in this script. Joint commitment before execution."""
import hashlib, json, sys
import bitcoin
from bitcoin.core import CMutableTransaction, CMutableTxIn, CMutableTxOut, COutPoint, lx, CScript
from bitcoin.core.script import OP_RETURN, OP_0, SIGHASH_ALL, CScriptWitness
from bitcoin.core import CTxWitness, CTxInWitness
from bitcoin.wallet import CBitcoinSecret, P2WPKHBitcoinAddress

DIGEST = bytes.fromhex("345276f7de060469655d16cab10ea760384a4e2d25212c24faf80a8f30d79ff7")
UTXO = {"txid": "ef1fce199cf16d3d835ca7d3f2abc531144bbd97e9891578082285573120cf3f", "vout": 0, "value": 684}
KA = "/app/tmp_push/fh_push/tokenization-adoption/seed-mode/dropbox/dropbox_writer_key_mainnet.json"
API = "https://blockstream.info/api"
MARKER, VERSION = b"SQDR", 0x01

def sha(b): return hashlib.sha256(b).digest()
def dsha(b): return hashlib.sha256(sha(b)).digest()
def api(path, data=None):
    import urllib.request
    req = urllib.request.Request(API + path, data=(data.encode() if isinstance(data, str) else data),
                                 headers={"Content-Type": "text/plain"})
    return urllib.request.urlopen(req, timeout=60).read().decode()

N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
def der_parse(sig):
    assert sig[0] == 0x30; i = 2
    assert sig[i] == 0x02; l = sig[i+1]; r = int.from_bytes(sig[i+2:i+2+l], "big"); i += 2 + l
    assert sig[i] == 0x02; l = sig[i+1]; s = int.from_bytes(sig[i+2:i+2+l], "big")
    return r, s
def der_encode(r, s):
    def enc(i):
        b = i.to_bytes((i.bit_length() + 7) // 8 or 1, "big")
        if b[0] & 0x80: b = b"\x00" + b
        return bytes([0x02, len(b)]) + b
    body = enc(r) + enc(s)
    return bytes([0x30, len(body)]) + body
def low_s(sig):
    r, s = der_parse(sig)
    if s > N // 2: s = N - s
    return der_encode(r, s)
def wpkh_addr(secret):
    h160 = hashlib.new("ripemd160", sha(bytes(secret.pub))).digest()
    return P2WPKHBitcoinAddress.from_scriptPubKey(CScript([OP_0, h160]))
def bip143(tx, idx, amount, h160):
    script_code = b"\x19\x76\xa9\x14" + h160 + b"\x88\xac"
    prevouts = b"".join(ti.prevout.serialize() for ti in tx.vin)
    seqs = b"".join(ti.nSequence.to_bytes(4, "little") for ti in tx.vin)
    outs = b"".join(to.serialize() for to in tx.vout)
    preimage = (tx.nVersion.to_bytes(4,"little") + dsha(prevouts) + dsha(seqs) +
                tx.vin[idx].prevout.serialize() + script_code + amount.to_bytes(8,"little") +
                tx.vin[idx].nSequence.to_bytes(4,"little") + dsha(outs) +
                tx.nLockTime.to_bytes(4,"little") + (1).to_bytes(4,"little"))
    return dsha(preimage)

# --- BTC leg: single input, single OP_RETURN output, postage-only (684 sats fee) ---
wif = json.load(open(KA))["wif"]
secret = CBitcoinSecret(wif)
addr = wpkh_addr(secret)
h160 = hashlib.new("ripemd160", sha(bytes(secret.pub))).digest()
payload = MARKER + bytes([VERSION]) + DIGEST
txin = CMutableTxIn(COutPoint(lx(UTXO["txid"]), UTXO["vout"])); txin.scriptSig = CScript()
tx = CMutableTransaction([txin], [CMutableTxOut(0, CScript([OP_RETURN, payload]))])
tx.vin[0].nSequence = 0xFFFFFFFF
sighash = bip143(tx, 0, UTXO["value"], h160)
sig = low_s(secret.sign(sighash)) + b"\x01"
wit = CTxWitness([CTxInWitness(CScriptWitness([sig, bytes(secret.pub)]))])
tx.wit = wit
raw = tx.serialize().hex()
txid = bitcoin.core.b2lx(dsha(tx.serialize()))
# keyless self-verify: reconstruct OP_RETURN from raw
parsed = json.loads(api(f"/tx/{txid}")) if False else None
print("BTC signed txid:", txid)
print("BTC raw vsize:", len(tx.serialize()) , "bytes; fee = 684 sats (entire input, postage-only)")
json.dump({"txid": txid, "raw": raw, "fee_sats": 684,
           "payload_hex": payload.hex(), "input": f"{UTXO['txid']}:{UTXO['vout']}"},
          open("/app/tmp_push/satoshi-dropbox/dwr-1/btc_dwr.json","w"), indent=1)

# --- XRP leg: pure storage write (AccountSet + memo, nothing moves) ---
from xrpl.wallet import Wallet
from xrpl.models.transactions import Payment, Memo
import xrpl.core.binarycodec as bc

wA = Wallet.from_seed(json.load(open("/app/tmp_push/fh_push/tokenization-adoption/xrp-rail/xrp_writer_key_mainnet_a.json"))["seed"])
from xrpl.models.transactions import AccountSet
tx_xrp = AccountSet(account=wA.classic_address, fee="10", sequence=107745078,
                 last_ledger_sequence=107754680,
                 memos=[Memo(memo_type="SQDR-XRP-STORE-1".encode().hex(),
                              memo_format="hex".encode().hex(),
                              memo_data=DIGEST.hex())])
blob = bc.encode(tx_xrp.to_xrpl())  # unsigned; sign properly via wallet
from xrpl.transaction import sign as xrpl_sign
signed = xrpl_sign(tx_xrp, wA)
blob = bc.encode(signed.to_xrpl())
h = hashlib.sha512(bytes.fromhex("54584E00" + blob)).digest()[:32].hex().upper()
print("XRP signed txid (SHA512-half):", h)
print("XRP self-send A:", wA.classic_address, "| fee 10 drops | seq 107745078")
json.dump({"txid": h, "account": wA.classic_address, "fee_drops": 10,
           "sequence": 107745078, "memo_type": "SQDR-XRP-STORE-1",
           "memo_data": DIGEST.hex(),
           "signed_blob": blob}, open("/app/tmp_push/satoshi-dropbox/dwr-1/xrp_dwr.json","w"), indent=1)
print("BOTH LEGS SIGNED OFFLINE — NOTHING BROADCAST")
