# DWR-1: The Dual-Write Receipt
## Simultaneous Dual-Rail Storage of a 32-Byte Digest on Bitcoin and XRPL Mainnets
### Ceremony Specification v1.0

**Operator:** Leon Calvin Long II — SQUIRL OS Technologies
**Runtime:** Deterministic tokenization stack, no LLM in the decision path
**Date:** October 18, 2026
**Ceremony type:** DWR-1 (dual-write receipt) — first of its kind in this corpus

---

## 1. Motivation

Prior ceremonies in this corpus tokenized artifacts by (a) binding a digest to Bitcoin
via an OP_RETURN output and (b) carrying the digest across an XRPL custody round trip.
Both rails store data permanently — an OP_RETURN output is pruned nothing and lives in
every full node's UTXO-set history forever; an XRPL memo is part of an immutable,
validated ledger sequence. What was demonstrated, not asserted, in every prior ceremony
was the WRITE itself, verified by a keyless reader pulling the payload back from the
chain and comparing it byte for byte against the frozen local artifact.

DWR-1 upgrades the doctrine from *storage plus custody demonstration* to **dual-write
storage**: the same 32-byte digest is written to BOTH rails in a single ceremony, under
a single frozen pre-registration, with both transaction identities committed BEFORE
either broadcast. The two writes are not chained or dependent — they are two
independent permanent copies of the same payload, stored on two networks with
independent failure modes, committed jointly.

## 2. The Atomicity Question (answered deterministically)

There is no truly atomic cross-chain write: no protocol exists that lands a Bitcoin
output and an XRPL transaction in the same global instant, and none is claimed here.
The deterministic equivalent — the same doctrine that governs every gate in this
system — is **joint prior commitment**:

1. Both transactions are fully constructed and signed offline.
2. Both resulting transaction identifiers are written into the frozen pre-registration,
   and the pre-registration is hashed. Neither chain has been touched at this point.
3. Both transactions are broadcast back-to-back (the broadcast interval is recorded).
4. Each chain independently timestamps its own write.

Any verifier can therefore prove, without trusting the operator: (a) the intent to make
both writes existed before either write hit a chain, because both txids were committed
in a hashed pre-registration; and (b) the two stored payloads are byte-identical, by
reading both chains keylessly. The commitment is the guarantee, not the timing.

## 3. Payload Doctrine

- Payload (Bitcoin): OP_RETURN, 37 bytes = marker "SQDR" + version byte 0x01 + 32-byte
  SHA-256 digest of the frozen artifact. No sats carried in the payload; postage-only.
- Payload (XRPL): Payment, self-addressed (A -> A, no custody transfer), carrying a
  memo of type SQDR-XRP-STORE-1 whose data field is the same 32-byte digest.
- The artifact for DWR-1 is this specification itself (self-referential, per the
  Satoshi Embodiment precedent).

## 4. Gates

| Gate | Test | Ceiling |
|------|------|---------|
| G1 | Bitcoin OP_RETURN write broadcast and confirmed | fee < 1,500 sats |
| G2 | XRPL memo write broadcast and validated | fee <= 20 drops |
| G3 | Keyless readers on both rails return payload | byte-exact |
| G4 | Pre-registration contains both txids before broadcast | sha256 frozen |

## 5. Pre-registered Predictions

1. Bitcoin write fee will be under 1,500 sats (postage-only, single confirmed UTXO).
2. XRPL write fee will be at or under 20 drops (self-send, open ledger).
3. Both payloads will read back byte-exact from both rails via keyless readers.
4. Both txids will appear in the frozen pre-registration (joint commitment).

> This software is a prototype and is provided for educational and research purposes
> only. It is not intended for production use, commercial deployment, or
> safety-critical environments. All systems are experimental and may contain defects.
