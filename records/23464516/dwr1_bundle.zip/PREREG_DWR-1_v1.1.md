# PREREGISTRATION — DWR-1 (Dual-Write Receipt, Ceremony 1)
**Frozen (v1.1):** 2026-10-19 ~00:02 CT — BEFORE either broadcast. Neither chain touched.

> **AMENDMENT DISCLOSURE (v1 -> v1.1, pre-broadcast):** The v1 prereg (sha256
> df244ee0...baff5, retained on disk for the record) committed BTC txid
> d580ca9e...c865969, whose witness signature was non-canonical DER (hashtype byte
> misplaced in the signer). Bitcoin's own mempool policy gate REJECTED it before
> broadcast — no chain state was touched. The signer was corrected and the amended
> commitment below is the operative one. Nothing was re-broadcast; the v1 txid never
> existed on any chain. The network's policy gate is itself a cage; it held.

## Artifact
DWR-1 spec: "The Dual-Write Receipt — Simultaneous Dual-Rail Storage of a 32-Byte
Digest on Bitcoin and XRPL Mainnets (v1.0)" — file DWR1_SPEC_v1.0.md, sha256:
345276f7de060469655d16cab10ea760384a4e2d25212c24faf80a8f30d79ff7

## Joint commitment (both transactions signed offline; txids committed below)
- **Bitcoin write:** txid `163cd18bcddea3415c7cfd64a12717206a8b83a345ae20b953f9a4c6a759ff26`
  OP_RETURN payload (37 bytes): `5351455201` + digest. Input: single confirmed UTXO
  `ef1fce199cf16d3d835ca7d3f2abc531144bbd97e9891578082285573120cf3f:0` (684 sats,
  block 972098 — the DGPNM homecoming remainder). Entire input is postage: fee 684
  sats, no change output. 207 bytes.
- **XRPL write:** txid `5C854DA468BD16CBC8C34423ABC088E3E4054E7DD89ED7EC4EA9889AE8EC26EB`
  AccountSet (pure storage write — NO payment, nothing moves) from
  `rBbxYuBkzK6UxKXhvUi8uNtdxhD1h7ZFGR`, sequence 107745078, fee 10 drops,
  memo type `SQDR-XRP-STORE-1`, memo data = digest.

## Pre-registered predictions
1. Bitcoin write fee (684 sats) < 1,500-sat ceiling. POSTAGE-ONLY: entire input consumed.
2. XRPL write fee (10 drops) <= 20-drop ceiling. NO VALUE MOVES — first non-payment
   storage write in this corpus.
3. Keyless readers on both rails will return the 37-byte OP_RETURN and the memo digest
   byte-exact against 345276f7...79ff7.
4. Both txids above appear in this frozen prereg BEFORE either broadcast — the joint
   prior commitment that substitutes for cross-chain atomicity.
5. Broadcast interval between the two legs will be under 60 seconds (recorded in runlog).

## Doctrine
Deterministic payload, writer-side keys only, no LLM in the decision path, no custody
transfer on either leg — this ceremony is pure dual-rail STORAGE.
