# LINDY Weekly Program Receipts — 2026-10-15 through 2026-10-31

Two weekly deterministic checks run on a Friday 22:30 CT cadence against frozen preregistrations.
This bundle is the evidence pack for that program to date.

- **LINDY-B — trajectory identity and canary scan.** Recomputes the trajectory-to-canonical hash and
  compares it to the pinned baseline `t2c_hash ca575bb9b781c47908bb13c24ba5739021e1fc15f33bc245257836d866f93d50`,
  checks lineage 106/106, 2646 crossings, and reconstructs a closure report against a 1e-04 budget.
- **LINDY-C — cage containment falsifiers FC1-FC5.** Instrument integrity over 12 frozen hashes,
  containment truth, a positive control (admitted 8/2/2), 8/8 adversarial candidates rejected with zero
  side effects, and journal invariant 8 == admitted with canonical journal hash
  `d51cd63369c913eb7090a09040f73104b6b379d442156c1b13e6adf1f5d86b98`.

## Results on the record

| Week (slot sig) | LINDY-B | LINDY-C |
|---|---|---|
| 2026-10-15 | PASS | PASS (after a same-night repaired runner path defect) |
| 2026-10-17 | PASS (re-run; first attempt missed on a displaced telemetry pack) | PASS (re-run; first attempt missed on an absent input pack) |
| 2026-10-24 | PASS per ledger 0324, slot sig lindy_b/2026-10-23 | PASS |
| 2026-10-31 | PASS | PASS |

Every PASS in this table reproduces the pinned baseline byte-for-byte: no drift in the LINDY-B
trajectory hash and no change in the LINDY-C canonical journal hash.

## Disclosures

1. **Two path-defect misses, both disclosed at the time and repaired the same night.** Neither was a
   result about the system under test: each was a harness path defect (a displaced telemetry pack in
   LINDY-B, an absent input pack in LINDY-C) that aborted the run before candidates executed. Neither
   harness nor corpus byte was modified to obtain the pass; both repairs restored expected paths.
2. **Bookkeeping gap, stated rather than papered over: the 2026-10-23 LINDY-B row is absent from
   `LINDY_B_RUNLOG.md`.** The pass is recorded in the project ledger (entry 0324, slot sig
   `lindy_b/2026-10-23`) with its full hash evidence, and the public feed carries the week as PASS. The
   runlog omission is a recording defect, not a disputed result, and it is left visible here instead of
   being back-filled to look complete.
3. **LINDY-C carries five clean passes** (10-15, the 10-17 re-run, 10-24, 10-31) against two disclosed
   path-defect misses.
4. **Synthetic corpus only.** No production, customer, client, or personal data is in this bundle, and no
   PHI appears anywhere in it. No operator chat text is included.
5. **Prototype.** This is research evidence for a prototype system, not a production-hardened product,
   and it carries no production warranty.
6. **No on-chain anchoring is part of this record.** The receipts are git-committed and hash-addressed.
7. **Dual Mesh Benchmark: NOT MEASURED for these runs.** LINDY-B and LINDY-C are deterministic
   trajectory and containment checks, not LLM capability benchmarks. Measured DMB columns are published
   separately, for example DOI 10.5281/zenodo.23609232 (frontier leg) and DOI 10.5281/zenodo.23345241
   (DeepSeek leg, scoped measurement).

## Bundle contents

`LINDY_B_RUNLOG.md`, `LINDY_C_RUNLOG.md`, `lindy_b_prereg.md`, `lindy_c_prereg.md`,
`lindy_b_baseline.json`, `lindy_b_runner.py`, `lindy_c_runner.py`, this README, and `MANIFEST.sha256`
(sha256 of every file in the bundle, excluding the manifest itself).
