# XPLAT Amendment 2 — ENV-B validation normalization + 429 retry policy (2026-10-12, committed BEFORE re-attempt)

## Observed on first ENV-B pass (all 20 attempts recorded in ENVB_RESULTS.json, pass 1)
- 9/20: clean-parse valid tuples (raw JSON, no fences).
- 8/20: model emitted the CORRECT tuple array wrapped in markdown fences (```json ... ```), which the raw json.loads validator (identical to the 20261011 baseline validator) rejects on parse. Fence-wrapping is a formatting artifact of the external substrate, not a resolution failure; the tuple inside is byte-identical to the required schema.
- 3/20: HTTP 429 (OpenRouter free-tier rate limit) — no response body measured.

## Amendment (binding for the ENV-B leg)
1. **Normalization step (validator only):** strip markdown code fences before json.loads. Semantics of tuple validation are UNCHANGED (exact playbook match, match_type, steps, status, position, anomaly_type). Raw responses preserved verbatim; per-instance fence status is recorded (clean vs fence-wrapped) so the strict-parser score (9/20) is also reported alongside the normalized score.
2. **429 retry policy:** up to 5 retries per instance, exponential backoff (5s, 10s, 20s, 40s, 80s). Every attempt (including 429s) is recorded with its own wall-clock. The instance's reported wall-clock is the successful attempt's request-to-validated-tuple time; the attempt count is disclosed.
3. **No data removal:** all 20 first-pass results remain in the record; the summary reports pass-1 strict score AND final normalized score.

## Disclosure in the receipt
ENV-B is measured on an external substrate whose output formatting (markdown fences) and rate behavior (429s) are part of the environment being characterized; both are disclosed rather than silently absorbed. Prototype disclaimer applies.
