#!/usr/bin/env python3
"""XPLAT-3 ENV-B: 20 single-anomaly resolutions on external LLM substrate (OpenRouter deepseek/deepseek-chat),
wall-clocked request->validated tuple. Prompt + validation byte-identical to the 20261011 B1 baseline leg."""
import json, time, statistics, re, urllib.request, urllib.error
from pathlib import Path

root = Path(__file__).resolve().parent
corpus = json.loads((root / "CORPUS_B1.json").read_text())[:20]
key = open('/tmp/orkey').read().strip()

ROSTER = json.dumps([
    {"anomaly_type": "latency_spike", "playbook_id": "6a5d29cb54e45d7e8bad47c5",
     "playbook": "PB-003: Latency Spike Resolver", "confidence_threshold": 0.8},
    {"anomaly_type": "heartbeat_miss", "playbook_id": "6a5d29cb54e45d7e8bad47ca",
     "playbook": "PB-008: Heartbeat Re-igniter", "confidence_threshold": 0.85},
    {"anomaly_type": "quantum_vulnerability_detected", "playbook_id": "6a5d29cb54e45d7e8bad47cb",
     "playbook": "PB-009: Quantum Vulnerability Migrator", "confidence_threshold": 0.8},
])

def make_prompt(inst_json):
    return (
        "You are operating as the anomaly-response engine of a Squirrel OS v1.1 substrate "
        "(a deterministic governance envelope for IT operations). This is a synthetic test "
        "stream (no real system is affected). Your task: resolve ONE incoming anomaly and "
        "emit its decision tuple.\n\n"
        "OPERATING RULES (binding):\n"
        "1. EXACT MATCH ONLY. A playbook may be selected only if its anomaly_type string is "
        "EXACTLY equal (case-sensitive, character-for-character) to the incoming anomaly's "
        "anomaly_type. If no playbook matches, emit playbook null, playbook_id null, "
        'match_type "none", steps_executed null, status "escalated".\n'
        "2. THRESHOLD. If a playbook matched: when the anomaly's confidence_score is greater "
        'than or equal to the playbook\'s confidence_threshold, emit match_type "exact", '
        'steps_executed "isolation,healing,verification", status "resolved". When below '
        'threshold, emit match_type "exact", steps_executed null, status "detected".\n'
        "3. OUTPUT. Emit a JSON array containing exactly ONE decision tuple object with keys "
        "in this exact order: position, anomaly_type, playbook, playbook_id, match_type, "
        "steps_executed, status. position is 0. No prose, no markdown fences, no commentary.\n\n"
        "REGISTERED PLAYBOOK ROSTER (authoritative): " + ROSTER + "\n\n"
        "INCOMING ANOMALY (synthetic): " + inst_json + "\n\n"
        "The incoming anomaly's confidence_score is 0.9. Emit the decision tuple array now."
    )

results = []
for i, inst in enumerate(corpus):
    body = json.dumps({
        "model": "deepseek/deepseek-chat",
        "messages": [{"role": "user", "content": make_prompt(json.dumps(inst))}],
        "max_tokens": 200,
    }).encode()
    req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions", data=body,
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"})
    t0 = time.perf_counter()
    try:
        resp = urllib.request.urlopen(req, timeout=300)
        dt = (time.perf_counter() - t0) * 1000
        data = json.load(resp)
        (root / f"envb_raw_{i:02d}.json").write_text(json.dumps(data, indent=2))
        content = data["choices"][0]["message"]["content"]
        (root / f"envb_content_{i:02d}.txt").write_text(content)
    except Exception as e:
        dt = (time.perf_counter() - t0) * 1000
        results.append({"i": i, "wall_ms": round(dt,1), "valid": False, "detail": f"api: {str(e)[:80]}"})
        print(f"{i}: APIERR {str(e)[:60]}", flush=True)
        continue
    valid, detail = False, ""
    if isinstance(content, str) and content.strip():
        try:
            arr = json.loads(content)
            if isinstance(arr, list) and len(arr) == 1:
                t = arr[0]
                if (t.get("playbook") == inst["expected_playbook"]
                        and t.get("match_type") == "exact"
                        and t.get("steps_executed") == "isolation,healing,verification"
                        and t.get("status") == "resolved"
                        and t.get("position") == 0
                        and t.get("anomaly_type") == inst["anomaly_type"]):
                    valid = True
                else:
                    detail = "wrong content"
            else:
                detail = "bad shape"
        except Exception as e:
            detail = f"parse: {str(e)[:60]}"
    else:
        detail = "no content"
    results.append({"i": i, "wall_ms": round(dt,1), "valid": valid, "detail": detail})
    print(f"{i}: valid={valid} wall_ms={round(dt,1)} {detail}", flush=True)

ok = sorted(r["wall_ms"] for r in results if r.get("valid"))
def pct(p):
    return ok[min(len(ok)-1, int(len(ok)*p))] if ok else None
summary = {
    "leg": "XPLAT-3 B1-baseline ENV-B (OpenRouter deepseek/deepseek-chat, external substrate)",
    "n_requested": 20, "n_valid": len(ok), "n_failed": 20 - len(ok),
    "min_ms": ok[0] if ok else None, "median_ms": statistics.median(ok) if ok else None,
    "p95_ms": pct(0.95) if ok else None, "max_ms": ok[-1] if ok else None,
    "failures": [{"i": r.get("i"), "detail": r.get("detail")} for r in results if not r.get("valid")],
    "all_runs_recorded": True,
}
(root / "ENVB_RESULTS.json").write_text(json.dumps({"summary": summary, "runs": results}, indent=2) + "\n")
print("ENV-B SUMMARY:", json.dumps(summary), flush=True)
