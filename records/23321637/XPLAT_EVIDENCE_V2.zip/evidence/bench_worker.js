// XPLAT-2 ENV-A: Cloudflare Workers edge host — dual mesh cross-platform benchmark leg.
// Purpose-built for dual_mesh_benchmark_xplat_20261012; deleted after the leg.
// 20 fresh conversations, wall-clocked request->validated-tuple, validation identical to 20261011 baseline.
const AGENT_ID = "69b57683f2623117603736bc";
const API = "https://base44.app";

export default {
  async fetch(request, env) {
    const u = new URL(request.url);
    if (u.pathname !== "/run") return new Response("no route", { status: 404 });
    if (!env.ADMIN_KEY || u.searchParams.get("key") !== env.ADMIN_KEY) return new Response("forbidden", { status: 403 });
    if (!env.AGENT_API_KEY) return new Response("no api key bound", { status: 500 });
    const headers = { "api_key": env.AGENT_API_KEY, "Content-Type": "application/json" };
    const corpus = JSON.parse(env.CORPUS20);
    const ROSTER = JSON.stringify([
      { anomaly_type: "latency_spike", playbook_id: "6a5d29cb54e45d7e8bad47c5", playbook: "PB-003: Latency Spike Resolver", confidence_threshold: 0.8 },
      { anomaly_type: "heartbeat_miss", playbook_id: "6a5d29cb54e45d7e8bad47ca", playbook: "PB-008: Heartbeat Re-igniter", confidence_threshold: 0.85 },
      { anomaly_type: "quantum_vulnerability_detected", playbook_id: "6a5d29cb54e45d7e8bad47cb", playbook: "PB-009: Quantum Vulnerability Migrator", confidence_threshold: 0.8 },
    ]);
    const makePrompt = (inst) =>
      "You are operating as the anomaly-response engine of a Squirrel OS v1.1 substrate " +
      "(a deterministic governance envelope for IT operations). This is a synthetic test " +
      "stream (no real system is affected). Your task: resolve ONE incoming anomaly and " +
      "emit its decision tuple.\n\n" +
      "OPERATING RULES (binding):\n" +
      "1. EXACT MATCH ONLY. A playbook may be selected only if its anomaly_type string is " +
      "EXACTLY equal (case-sensitive, character-for-character) to the incoming anomaly's " +
      "anomaly_type. If no playbook matches, emit playbook null, playbook_id null, " +
      'match_type "none", steps_executed null, status "escalated".\n' +
      "2. THRESHOLD. If a playbook matched: when the anomaly's confidence_score is greater " +
      "than or equal to the playbook's confidence_threshold, emit match_type \"exact\", " +
      'steps_executed "isolation,healing,verification", status "resolved". When below ' +
      'threshold, emit match_type "exact", steps_executed null, status "detected".\n' +
      "3. OUTPUT. Emit a JSON array containing exactly ONE decision tuple object with keys " +
      "in this exact order: position, anomaly_type, playbook, playbook_id, match_type, " +
      "steps_executed, status. position is 0. No prose, no markdown fences, no commentary.\n\n" +
      "REGISTERED PLAYBOOK ROSTER (authoritative): " + ROSTER + "\n\n" +
      "INCOMING ANOMALY (synthetic): " + JSON.stringify(inst) + "\n\n" +
      "The incoming anomaly's confidence_score is 0.9. Emit the decision tuple array now.";

    const runs = [];
    for (let i = 0; i < corpus.length; i++) {
      const inst = corpus[i];
      const rec = { i, instance_echo: inst };
      try {
        const cr = await fetch(`${API}/api/agents/${AGENT_ID}/conversations`, {
          method: "POST", headers, body: JSON.stringify({ name: `XPLAT-BENCH-${i}` }) });
        if (!cr.ok) { rec.error = "conv create " + cr.status + " " + (await cr.text()).slice(0, 120); runs.push(rec); continue; }
        const conv = await cr.json();
        const cid = conv.id || conv._id;
        if (!cid) { rec.error = "no conversation id"; runs.push(rec); continue; }
        rec.conversation_id = cid;
        const t0 = Date.now();
        const r = await fetch(`${API}/api/agents/${AGENT_ID}/conversations/${cid}/messages`, {
          method: "POST", headers, body: JSON.stringify({ content: makePrompt(inst) }) });
        const dt = Date.now() - t0;
        rec.wall_ms = dt;
        const body = await r.text();
        if (!r.ok) { rec.error = "send " + r.status + " " + body.slice(0, 120); runs.push(rec); continue; }
        let data; try { data = JSON.parse(body); } catch (e) { rec.error = "parse " + e; runs.push(rec); continue; }
        let content = null;
        if (data && data.role === "assistant") content = data.content;
        if (content === null && data && Array.isArray(data.messages)) {
          const cands = data.messages.filter((m) => m.role === "assistant");
          if (cands.length) content = cands[cands.length - 1].content;
        }
        rec.raw_reply = typeof content === "string" ? content : null;
        let valid = false, detail = "no content";
        if (typeof content === "string" && content.trim()) {
          try {
            const arr = JSON.parse(content);
            if (Array.isArray(arr) && arr.length === 1) {
              const t = arr[0];
              if (t.playbook === inst.expected_playbook && t.match_type === "exact" &&
                  t.steps_executed === "isolation,healing,verification" && t.status === "resolved" &&
                  t.position === 0 && t.anomaly_type === inst.anomaly_type) { valid = true; detail = ""; }
              else detail = "wrong content";
            } else detail = "bad shape";
          } catch (e) { detail = "parse " + ("" + e).slice(0, 60); }
        }
        rec.valid = valid; rec.detail = detail;
      } catch (e) { rec.error = "" + e; }
      runs.push(rec);
    }
    const ok = runs.filter((r) => r.valid).map((r) => r.wall_ms).sort((a, b) => a - b);
    const median = ok.length ? ok[Math.floor(ok.length / 2)] : null;
    const summary = {
      leg: "XPLAT-2 B1-baseline ENV-A (Cloudflare Workers edge host)",
      n_requested: runs.length, n_valid: ok.length, n_failed: runs.length - ok.length,
      min_ms: ok[0] ?? null, median_ms: median, p95_ms: ok.length ? ok[Math.min(ok.length - 1, Math.floor(ok.length * 0.95))] : null,
      max_ms: ok.length ? ok[ok.length - 1] : null,
      failures: runs.filter((r) => !r.valid).map((r) => ({ i: r.i, detail: r.detail || r.error })),
      corpus_source_sha256: env.CORPUS_SHA || "unbound",
      all_runs_recorded: true,
    };
    return new Response(JSON.stringify({ summary, runs }, null, 2), { headers: { "Content-Type": "application/json" } });
  },
};
