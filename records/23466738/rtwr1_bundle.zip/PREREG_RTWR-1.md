# PREREGISTRATION — RTWR-1: FIRST RECURSIVE TRI-TOKENIZATION

**Ceremony ID:** RTWR-1 (Recursive Tri-Write No. 1)
**Type:** Tri-write storage ceremony (same class as TWR-1)
**Purpose:** The first tokenization of a tokenization receipt — the record of the first
tri-write (TWR-1), stored on the same three mainnets that made it historic. The evidence
of the capability, carried by the capability itself.

## Artifact (frozen before broadcast)
- **File:** TWR1_RECEIPT.md
- **Digest (SHA-256):** 62a98c6b573578c6ba78cde5c668f0af712690c00be89437f13939c9c82e7f39
- **Content boundary:** hash-only on all rails (POL-DISC-001); no client data, no PHI,
  no credentials.

## Planned rails (joint commitment — all three fail or none count)
1. **Bitcoin mainnet** — OP_RETURN, payload SQDR + 0x01 + digest (37 bytes, hash-only),
   postage from writer wallet A UTXO 13ccf51f...d4d501b:1 (85,363 sats), change home to A,
   fee ~700 sats. IDENTIFIER DOCTRINE (ledger 0228): the canonical txid is computed locally
   over the NON-WITNESS serialization and recorded here as the identifier of record; any
   witness-extended id returned by an endpoint is disclosed, never committed.
2. **XRPL mainnet** — AccountSet non-payment storage write, memo SQDR-XRP-STORE-3 +
   digest, 10 drops, sequence 107745080.
3. **Stellar mainnet** — ManageData SQDR-STORE-2 (32-byte digest, zero transfer) +
   memo_hash, 100 stroops base fee, account sequence 279261054213554177.
   IDENTIFIER DOCTRINE: the network transaction hash from Horizon is the identifier of
   record, NOT the envelope hash (TWR-1 defect, disclosed).

## Gates
- G1 BUILD: all three legs signed offline; canonical identifiers computed and committed
  pre-broadcast (this document).
- G2 BROADCAST: back-to-back, ceiling 90s interval.
- G3 READ-BACK: keyless, byte-exact on all three rails.
- G4: identifier forms correct per rail (BTC canonical txid; XRP hash; Stellar network hash).
- G5 DOI: Zenodo record minted with receipts after verification.

## Costs (planned ceiling)
700 sats + 10 drops + 100 stroops.

## Authorization
Leon GO (chat authorization, 2026-10-19 ~01:32 CT). Prototype disclaimer applies.
