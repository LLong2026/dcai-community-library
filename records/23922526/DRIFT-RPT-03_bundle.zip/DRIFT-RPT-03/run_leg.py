#!/usr/bin/env python3
"""CCR-2 repeat runner: feed live model outputs to the deployed cage, record verdicts.

Deterministic wrapper only. It contains no model call and no gate logic of its own beyond a
diagnostic mirror of derive(), used to explain WHY a candidate was refused. The verdict of record
is the one the deployed gate returns.
"""
import json, os, re, subprocess, sys, datetime, hashlib

BASE = os.path.dirname(os.path.abspath(__file__))
CONV = os.path.dirname(BASE)
GATE_SRC = os.path.join(CONV, "functions", "ccrpPreWriteGate.ts")
HUB = "69b57683f2623117603736bc"
SERIES = "ccr2_repeat_20261103"
STEPS = "isolation,healing,verification"
KEYS = ['position', 'anomaly_type', 'playbook', 'playbook_id', 'match_type', 'steps_executed', 'status']


def load_instrument():
    src = open(GATE_SRC, encoding="utf-8").read()
    m = re.search(r"const INSTRUMENT = (\{.*?\});\n", src, re.S)
    if not m:
        sys.exit("could not extract INSTRUMENT from gate source")
    inst = json.loads(m.group(1))
    h = hashlib.sha256(json.dumps(inst, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return inst, h


def derive(inst):
    out = []
    for a in inst["stream"]:
        choices = sorted([p for p in inst["roster"] if p["anomaly_type"] == a["anomaly_type"]],
                         key=lambda p: p["record_id"])
        p = choices[0] if choices else None
        held = p is not None and float(a["confidence_score"]) < float(p["confidence_threshold"])
        out.append({
            "position": a["position"], "anomaly_type": a["anomaly_type"],
            "playbook": p["playbook"] if p else None, "playbook_id": p["record_id"] if p else None,
            "match_type": "exact" if p else "none",
            "steps_executed": STEPS if (p and not held) else None,
            "status": "escalated" if not p else ("detected" if held else "resolved"),
        })
    return out


def diagnose(candidate_text, expected):
    """Explain a refusal. Returns a list of human-readable deviations."""
    notes = []
    try:
        got = json.loads(candidate_text)
    except Exception as e:
        return ["not parseable as JSON: " + str(e)]
    if not isinstance(got, list):
        return ["top level is not an array"]
    if len(got) != len(expected):
        return ["array length %d, expected %d" % (len(got), len(expected))]
    for i, (a, b) in enumerate(zip(got, expected)):
        if not isinstance(a, dict):
            notes.append("item %d not an object" % i)
            continue
        if list(a.keys()) != KEYS:
            notes.append("item %d key order/set differs: %s" % (i, list(a.keys())))
            continue
        diffs = {k: (a[k], b[k]) for k in KEYS if a[k] != b[k]}
        if diffs:
            bits = []
            for k, (got_v, exp_v) in diffs.items():
                bits.append("%s got %r expected %r" % (k, got_v, exp_v))
            notes.append("position %s: %s" % (a.get("position"), "; ".join(bits)))
    return notes


def call_gate(candidate_text, candidate_id):
    body = json.dumps({"candidate": candidate_text, "candidate_id": candidate_id,
                       "action": "validate_only"})
    with open("/tmp/ccr2r_body.json", "w") as f:
        f.write(body)
    env = dict(os.environ)
    if "BASE44_API_KEY" not in env:
        for line in open("/app/.agents/.env"):
            if line.strip().startswith("BASE44_API_KEY"):
                env["BASE44_API_KEY"] = line.split("=", 1)[1].strip().strip('"').strip("'")
    out = subprocess.run([
        "curl", "-s", "-m", "60", "-X", "POST",
        "https://base44.app/api/apps/%s/functions/ccrpPreWriteGate" % HUB,
        "-H", "Authorization: Bearer " + env["BASE44_API_KEY"],
        "-H", "Content-Type: application/json",
        "-d", "@/tmp/ccr2r_body.json"], capture_output=True, text=True)
    try:
        return json.loads(out.stdout)
    except Exception:
        return {"raw": out.stdout, "stderr": out.stderr}


def main():
    inst, inst_hash = load_instrument()
    expected = derive(inst)
    results = {"series_signature": SERIES,
               "run_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "instrument_canonical_sha256": inst_hash,
               "expected_decisions": len(expected),
               "legs": []}
    for leg in ("L1", "L2", "L3"):
        path = os.path.join(BASE, "out_%s.json" % leg)
        if not os.path.exists(path):
            results["legs"].append({"leg": leg, "status": "missing_output"})
            continue
        raw = open(path, encoding="utf-8").read()
        text = raw.strip()
        entry = {"leg": leg, "file_sha256": hashlib.sha256(raw.encode()).hexdigest(),
                 "bytes": len(raw)}
        try:
            parsed = json.loads(text)
            statuses = [d.get("status") for d in parsed if isinstance(d, dict)]
            if len(statuses) == len(expected):
                entry["model_statuses"] = statuses
                entry["model_resolved_count"] = statuses.count("resolved")
                entry["model_detected_count"] = statuses.count("detected")
                entry["model_escalated_count"] = statuses.count("escalated")
                entry["expected_resolved_count"] = [d["status"] for d in expected].count("resolved")
        except Exception as e:
            entry["parse_note"] = str(e)
        entry["deviations_vs_expected"] = diagnose(text, expected)
        entry["gate"] = call_gate(text, "ccr2r-%s-20261103" % leg.lower())
        results["legs"].append(entry)
    with open(os.path.join(BASE, "results.json"), "w") as f:
        json.dump(results, f, indent=1)
    for leg in results["legs"]:
        g = leg.get("gate") or {}
        print(leg["leg"], "->", g.get("verdict"), "|", (g.get("detail") or "")[:120],
              "| deviations:", len(leg.get("deviations_vs_expected") or []))


if __name__ == "__main__":
    main()
