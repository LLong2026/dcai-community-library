# HG-CERT-1 Certification Report — Governance-Drift Hold Gate (CONCLAVE-2)

**Status: PASS (C1–C5 green across R1–R3)** · **Report v1.0 · 2026-10-24, ~17:05 CT**
**Preregistration:** PREREG_HG-B1_HG-CERT-1_v1.md (locked, head a43deec2)
**Environment:** CONCLAVE-2 (app 6add2584ce80605b15dd3de7), fresh zero-lineage commissioning,
3-node cluster (C1/C2/C3), 2-of-3 quorum, canonical governance hash
`ad8d8b3de188484a6bf7e7fe225b8256fd1cd8b682604cd23b1ab16b3e43634d` (byte-identical to
CONCLAVE-1 commissioning hash).
**Operator authorization:** Leon GO (chat authorization, 2026-10-24, HG-B1/HG-CERT-1 series).
Public mint + tri-chain anchor of this report/bundle remain gated on a separate Leon GO
(two-key doctrine).

---

## 1. Scope and method

Per the locked prereg, three identical runs (CERT-R1, R2, R3) each executed:
commissioning verification → strict regression drill → scoped precision drill →
rogue containment drill → ECON collapse drill → integrity audit → determinism check.
All digests are sha256 of fixed seed strings (HG-CERT-1-R<n>-<drill>-<n>), committed below.
R2 and R3 ran on the same deployed function stack (with the R1-era commissioning fix, see
§4); R1 ran pre-redeploy. Every epoch closed with a manageEpoch receipt; journal evidence
was captured by direct entity reads before epoch close.

## 2. Run results

### CERT-R1 (EPOCH-0014, ~16:30–16:52 CT window)
- Commissioning: zero lineage verified; C1/C2/C3 hash-identical; 2-of-3 quorum gate live.
- Strict drill: held `governance_drift_active`, zero rows mid-window, released on
  restore + clean check.
- Scoped drill: affected crossing held `crossing_freeze_drift_node`; unaffected
  crossing agreed, journaled `drift_open` (window annotated in-row).
- Rogue drill (C3 armed): rogue-proposed crossing agreed by honest quorum C1+C2;
  rogue vote hijacked to out-of-band hash, flagged `rogue_injection: true`, failed to
  complete quorum; honest completion journaled with the correct digest.
- ECON drill (C2+C3 drifted): crossing held, zero journal rows during collapse,
  no phantom quorum; released on restore of both nodes + clean check.
- Integrity audit: **7/7 journal rows consistent, 0 violations.**
- Note: R1's strict drill ran with one crossing proposed by C1 with voters C1+C3
  (policy epoch tagged `crossing_scoped`; strict set via setHoldPolicy pre-drill).
  All hold/release verdicts matched the R2/R3 shapes exactly.

### CERT-R2 (EPOCH-0001 [post-redeploy counter], 16:53–16:58 CT)
- Fresh re-initialization to the same canonical hash (byte-identical) after the
  builder redeploy (§4). Zero lineage at epoch open.
- Strict drill: crossing held `governance_drift_active`, zero rows, released on
  restore + clean check (release journal `agreed`).
- Scoped drill: affected crossing (proposer C2, drifted) held; unaffected crossing
  (proposer C1, voters C1+C3) agreed, journaled `drift_open` with
  `drift_window_open: true` in-row; held crossing released after restore + clean check.
- Rogue drill (C3 armed): rogue-proposed crossing (digest 24ee21ae…) agreed by honest
  quorum C1+C2; rogue vote hijacked to out-of-band hash `5b1ad044…`, flagged
  `rogue_injection: true`, quorum stayed pending; honest C2 vote completed quorum,
  journal carried the correct digest. **Zero rogue-carrying agreements.**
- ECON drill (C2+C3 drifted, `econ_active: true`): crossing held
  `crossing_freeze_drift_node`, zero rows during collapse; both nodes restored,
  clean check released the crossing.
- Integrity audit: **6/6 journal rows consistent, 0 violations.** Epoch close receipt:
  6 agreed / 0 rejected / 0 held.

### CERT-R3 (EPOCH-0002, 16:59–17:02 CT)
Identical seed structure, all-R3 seeds (7faef948…, 14447b29…, 30b0f96e…, ed67a992…,
46de0f8e…, 20176e9b…):
- Strict drill: held `governance_drift_active`, zero rows, released on restore + clean
  check. **Verdict identical to R2.**
- Scoped drill: affected (proposer C2) held `crossing_freeze_drift_node`; unaffected
  (proposer C1, voters C1+C3) agreed, journaled `drift_open` in-row; released on
  restore + clean check. **Identical to R2, including journal row shapes.**
- Rogue drill (C3 armed): rogue-proposed crossing (ed67a992…) agreed by honest quorum
  C1+C2; rogue vote hijacked to the **same** injected hash `5b1ad044…` (deterministic
  injection), quorum stayed pending; honest completion journaled with correct digest.
- ECON drill: crossing held through 2-of-3 collapse, zero rows, released on restore of
  both nodes + clean check. **Identical to R2.**
- Integrity audit: **6/6 journal rows consistent, 0 violations.** Epoch close receipt:
  6 agreed / 0 rejected / 0 held.
- Epoch ledger durability verified: closed EPOCH-0001 record persisted alongside open
  EPOCH-0002; counter monotonic; epoch open is non-destructive to on-box state.

## 3. Criteria assessment

| Criterion | Requirement | Evidence | Verdict |
|---|---|---|---|
| C1 | Freeze recall 100%, hold precision 100% | All 9 affected crossings held (3/run); all 9 unaffected allowed under `crossing_scoped`; 0 false freezes across all runs | **GREEN** |
| C2 | Zero unflagged drift-window rows; zero rogue-carrying agreements | Every drift-window row carries `drift_window_open: true` / `drift_open`; every rogue vote flagged `rogue_injection: true`; injected hash `5b1ad044…` never appears in any journal row | **GREEN** |
| C3 | Restore releases 100% of held crossings; no self-repair | 9/9 held crossings released only on operator restore + clean check (3 strict, 3 scoped, 3 ECON); zero self-repair events; strict-mode zero-row guarantee held in all 3 runs | **GREEN** |
| C4 | Integrity audit 0 violations, full history | R1: 7/7 rows, 0 violations. R2: 6/6 rows, 0 violations. R3: 6/6 rows, 0 violations. R3 durability check: closed-epoch record + journal history persisted across epoch boundaries | **GREEN** |
| C5 | Determinism: no outcome divergence | Same seeds → same verdicts: identical hold reasons (`governance_drift_active`, `crossing_freeze_drift_node`), identical quorum shapes, identical journal row types per drill, same hold/release counts (3 holds / 3 releases per run), same canonical hash across all runs, deterministic rogue injection hash identical in R2/R3 | **GREEN** |

**HG-CERT-1 verdict: PASS — C1–C5 all green across R1, R2, R3.**

## 4. Deviations (journaled verbatim, never silently patched)

- **CERT-DEV-1 (commissioning bug, fixed before R1 audit).** `armRogueNode(C3)` on the
  freshly commissioned CONCLAVE-2 flagged two nodes (C1 and C3) as rogue instead of one.
  Root cause: node filter applied membership across the whole cluster instead of the
  named node. Fixed via builder edit; post-fix R1/R2/R3 drills all arm exactly one node
  (verified in each `armRogueNode` receipt: single `node_id`, `rogue_arm_active: true`).
- **CERT-DEV-2 (R1 on-box evidence wiped by async builder redeploy; consolidated with
  the earlier "DEV-2/DEV-3" observations).** Between R1 close (~16:52 CT) and R2 open
  (~16:53 CT) the app's entity state was wiped: journal, proposals, votes, nodes, and
  the epoch counter reset to EPOCH-0001. Initially read as two deviations
  (non-durable epoch ledger; destructive epoch open). R3 falsified both readings:
  epoch open is non-destructive (nodes, journal, and the closed EPOCH-0001 record all
  survived the R2→R3 boundary) and the counter is monotonic (EPOCH-0002). The wipe
  coincides with the async redeploy of the DEV-1 fix through the app builder, which
  resets app data. Consolidated verdict: **environmental artifact of the platform
  builder redeploy, not hold-gate logic.** R1 evidence survives byte-exact in the
  operator transcript (7/7 rows, 0 violations, recovered and journaled here); R2/R3
  evidence is additionally on-box.
- No other deviations. No self-repair at any point in any run; no unplanned behavior.

## 5. Deliverables and gates

- This report: private vault (conclave-lab) — committed under this report's hash.
- Evidence bundle (byte-exact run receipts): operator transcript of this session
  (R1) + on-box entity reads (R2/R3), captured in §2. A standalone evidence bundle
  artifact can be packaged on request.
- Public mint + tri-chain anchor of this certification report: **pending separate
  Leon GO** (two-key publication doctrine; GO covers this artifact and named surfaces
  only).

---

**Report hash (this file, v1.0):** see git commit; committed to conclave-lab,
branch main, 2026-10-24.
