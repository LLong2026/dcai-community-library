# The Chain Is the Witness, Not the Asset — publication bundle

Artifact: paper_merged_witness.pdf (10 pages) — Part I: The Thesis (investor-facing);
Part II: The Practitioner's Walkthrough (vault, digest, triad, verify, reconstruct).

Figures: fig_two_stacks.png (the two stacks), fig_triad.png (the triad rails),
fig_cost.png (measured cost per receipt), fig_vault_table.png and fig_viewer_modal.png
(UAS product surface screenshots).

All cost figures are measured from live production anchors (receipts on file):
XLM leg 100 stroops / 6.7s; XRP leg 10 drops / 6.8s; BTC leg 790 sats single-tx,
~$0.019/receipt under weekly batch amortization. Worked examples carry live
transaction IDs on three public networks.

DISCLOSURE: no client-identifiable data, no PHI, no credentials, no operator
communication, no chat links. All examples are SQUIRL-INTERNAL or publicly
published receipts.

This software is a prototype and is provided for educational and research purposes
only. It is not intended for production use, commercial deployment, or safety-critical
environments. All systems are experimental and may contain defects.
